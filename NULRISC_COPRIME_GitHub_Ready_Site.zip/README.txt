NULRISC & COPRIME — GitHub‑ready Demo

How to publish
1) Create a public repo (e.g., nulrisc-coprime-demo).
2) Upload ALL files/folders from this ZIP to the repo root.
3) Repo → Settings → Pages → Source: main / root → Save.
4) Live link: https://<username>.github.io/<repo>/

Replace placeholders
- PDFs: /assets/pdfs/placeholder.pdf
- Audio: /assets/audio/sample.wav
- Images: /assets/img/thumb.png
- YouTube: open pages in /resources/en/ and swap the video ID.
